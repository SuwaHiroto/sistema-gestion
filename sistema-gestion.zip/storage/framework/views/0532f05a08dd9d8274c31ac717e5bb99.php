

<?php $__env->startSection('content'); ?>
    <div class="mb-8">
        <h2 class="text-2xl font-bold text-gray-800">Reportes y Métricas</h2>
        <p class="text-sm text-gray-500">Análisis de rendimiento del mes actual.</p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">

        <!-- Reporte de Ingresos por Mes (Tabla Simple) -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 class="font-bold text-gray-800 mb-4 flex items-center gap-2">
                <i class="fas fa-chart-line text-green-500"></i> Ingresos Recientes
            </h3>
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left">
                    <thead class="bg-gray-50 text-gray-600 uppercase text-xs">
                        <tr>
                            <th class="p-3">Mes</th>
                            <th class="p-3 text-right">Cant. Pagos</th>
                            <th class="p-3 text-right">Total (S/)</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $ingresosPorMes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingreso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="p-3 font-medium">
                                    <?php echo e(\Carbon\Carbon::createFromFormat('m', $ingreso->mes)->format('F')); ?></td>
                                <td class="p-3 text-right"><?php echo e($ingreso->cantidad); ?></td>
                                <td class="p-3 text-right font-bold text-green-600">S/
                                    <?php echo e(number_format($ingreso->total, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Reporte de Técnicos (Top 5) -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 class="font-bold text-gray-800 mb-4 flex items-center gap-2">
                <i class="fas fa-trophy text-yellow-500"></i> Top Técnicos (Servicios Finalizados)
            </h3>
            <ul class="space-y-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $topTecnicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div
                                class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-xs">
                                <?php echo e(substr($tec->nombres, 0, 1)); ?>

                            </div>
                            <span class="text-sm font-medium text-gray-700"><?php echo e($tec->nombres); ?>

                                <?php echo e($tec->apellido_paterno); ?></span>
                        </div>
                        <span class="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs font-bold">
                            <?php echo e($tec->servicios_count); ?> servicios
                        </span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </ul>
        </div>

    </div>

    <!-- Botón de Exportar (Simulado) -->
    <div class="mt-8 text-right">
        <button onclick="window.print()"
            class="bg-gray-800 hover:bg-gray-900 text-white font-bold py-2 px-4 rounded shadow inline-flex items-center gap-2">
            <i class="fas fa-print"></i> Imprimir Reporte
        </button>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC-304\Music\Yeremi\LARAVEL\sistema-gestion\resources\views/admin/reportes/index.blade.php ENDPATH**/ ?>